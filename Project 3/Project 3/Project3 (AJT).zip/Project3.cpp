//-------------------------------------------------------
//				CS 215 - Fall 2020 - Project 3  
//-------------------------------------------------------
// Author:  Andrew Tackett
// Section: 002
// I received help from: Amanda Jones, helped with the class declaration,
// main validation loops, sorting and writing registration file (regout.txt).
// 
//-------------------------------------------------------
#include "crapp.h"
using namespace std;

int main() {
	crapp c;
	c.go();
	return 0;
}